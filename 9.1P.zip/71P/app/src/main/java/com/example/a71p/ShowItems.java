package com.example.a71p;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import java.util.ArrayList;

public class ShowItems extends AppCompatActivity {

    private DbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show);

            dbHelper = new DbHelper(this);

                ListView listView = findViewById(R.id.list_view);

                ArrayList<String> itemsList = new ArrayList<>();
             final ArrayList<Integer> itemIdList = new ArrayList<>();

                SQLiteDatabase db = dbHelper.getReadableDatabase();
            //all this code here distinguishes the Database
        String[] projection = {
                DbHelper.COLUMN_ID,
                DbHelper.COLUMN_NAME,
                DbHelper.COLUMN_IS_LOST,
                DbHelper.COLUMN_IS_FOUND
        };

        String sortOrder = DbHelper.COLUMN_DATE + " DESC";

        Cursor cursor = db.query(
                    DbHelper.TABLE_NAME,
                 projection,
                    null,
                 null,
                 null,
                    null,
                  sortOrder
        );
            //Cursor function from week 7 tutorial videos

        while (cursor.moveToNext()) {
            int Lost = cursor.getInt(cursor.getColumnIndexOrThrow(DbHelper.COLUMN_IS_LOST));
            int Found = cursor.getInt(cursor.getColumnIndexOrThrow(DbHelper.COLUMN_IS_FOUND));
            String name = cursor.getString(cursor.getColumnIndexOrThrow(DbHelper.COLUMN_NAME));
            int id = cursor.getInt(cursor.getColumnIndexOrThrow(DbHelper.COLUMN_ID));

            String itemString = "Name: " + name;

            if (Lost == 1) {

                itemString += "\nLost";
            } else if (Found == 1) {
                itemString += "\nFound";
            }

            itemsList.add(itemString);
            itemIdList.add(id);
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, itemsList);
        listView.setAdapter(adapter);
            //onclick to item details class to check on what has been added to the list
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                int item = itemIdList.get(position);
                Intent intent = new Intent(ShowItems.this, ItemDetails.class);
                intent.putExtra("itemId", item);
                startActivity(intent);
            }
        });

        cursor.close();
    }

    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }
}
