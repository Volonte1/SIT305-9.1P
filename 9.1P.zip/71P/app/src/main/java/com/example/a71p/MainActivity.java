package com.example.a71p;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
            ////button that links to the create advert page
        Button btnCreate = findViewById(R.id.btnCreateAdvert);
            btnCreate.setOnClickListener(new View.OnClickListener() {
             @Override
                 public void onClick(View v) {
                        Intent intent = new Intent(MainActivity.this, CreateAdvert.class);
                        startActivity(intent);
            }
        });
            //button that links to the show items page
        Button btnShowItems = findViewById(R.id.btnShowItems);
            btnShowItems.setOnClickListener(new View.OnClickListener() {
                 @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(MainActivity.this, ShowItems.class);
                        startActivity(intent);
            }
        });
            //new code added for 9.1p another button for maps
        Button btn_ShowMap = findViewById(R.id.btn_ShowMap);
        btn_ShowMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MapsActivity.class);
                startActivity(intent);
            }
        });
    }
}