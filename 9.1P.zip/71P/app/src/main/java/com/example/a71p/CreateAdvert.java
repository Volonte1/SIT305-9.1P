package com.example.a71p;

import androidx.appcompat.app.AppCompatActivity;
import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

public class CreateAdvert extends AppCompatActivity {

    private DbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_advert);

        dbHelper = new DbHelper(this);

        final CheckBox isLostCheckBox = findViewById(R.id.isLostCheckBox);
        final CheckBox isFoundCheckBox = findViewById(R.id.isFoundCheckBox);
        final EditText nameEditText = findViewById(R.id.nameEditText);
        final EditText phoneEditText = findViewById(R.id.phoneEditText);
        final EditText descriptionEditText = findViewById(R.id.descriptionEditText);
        final EditText locationEditText = findViewById(R.id.locationEditText);
        final Button saveButton = findViewById(R.id.saveButton);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                ContentValues values = new ContentValues();
                values.put(DbHelper.COLUMN_IS_LOST, isLostCheckBox.isChecked() ? 1 : 0);
                values.put(DbHelper.COLUMN_IS_FOUND, isFoundCheckBox.isChecked() ? 1 : 0);
                values.put(DbHelper.COLUMN_NAME, nameEditText.getText().toString());
                values.put(DbHelper.COLUMN_PHONE, phoneEditText.getText().toString());
                values.put(DbHelper.COLUMN_DESCRIPTION, descriptionEditText.getText().toString());
                values.put(DbHelper.COLUMN_LOCATION, locationEditText.getText().toString());
                    //this is the DB helper that was used in the coursework but edited for 7.1p
                SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
                String Date = sdf.format(new Date());
                values.put(DbHelper.COLUMN_DATE, Date);

                db.insert(DbHelper.TABLE_NAME, null, values);

                Toast.makeText(CreateAdvert.this, "Advert created successfully", Toast.LENGTH_SHORT).show();

                finish();
            }
        });
    }

    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }
}
