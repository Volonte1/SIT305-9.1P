package com.example.a71p;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class ItemDetails extends AppCompatActivity {

    private DbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item);

        dbHelper = new DbHelper(this);

        int itemId = getIntent().getIntExtra("itemId", -1);

        SQLiteDatabase db = dbHelper.getReadableDatabase();

        String[] projection = {
                DbHelper.COLUMN_NAME,
                DbHelper.COLUMN_DESCRIPTION,
                DbHelper.COLUMN_LOCATION,
                DbHelper.COLUMN_DATE,
                DbHelper.COLUMN_IS_LOST,
                DbHelper.COLUMN_IS_FOUND,
                DbHelper.COLUMN_PHONE
        };

        String selection = DbHelper.COLUMN_ID + " = ?";
        String[] selectionArgs = { Integer.toString(itemId) };

        Cursor cursor = db.query(
                DbHelper.TABLE_NAME,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        TextView nameTextView = findViewById(R.id.text_view_name);

        TextView phoneTextView = findViewById(R.id.text_view_phone);

        TextView descriptionTextView = findViewById(R.id.text_view_description);

        TextView locationTextView = findViewById(R.id.text_view_location);

        TextView dateTextView = findViewById(R.id.text_view_date);

        TextView statusTextView = findViewById(R.id.text_view_is_lost_or_found);

        //declaress each variable and all the subsequent string that are associated to which bit of the database
        if (cursor.moveToFirst()) {
            String name = cursor.getString(cursor.getColumnIndexOrThrow(DbHelper.COLUMN_NAME));

                String description = cursor.getString(cursor.getColumnIndexOrThrow(DbHelper.COLUMN_DESCRIPTION));

                     String location = cursor.getString(cursor.getColumnIndexOrThrow(DbHelper.COLUMN_LOCATION));

                         String date = cursor.getString(cursor.getColumnIndexOrThrow(DbHelper.COLUMN_DATE));

                            String phone = cursor.getString(cursor.getColumnIndexOrThrow(DbHelper.COLUMN_PHONE));

                            int isLost = cursor.getInt(cursor.getColumnIndexOrThrow(DbHelper.COLUMN_IS_LOST));

                        int isFound = cursor.getInt(cursor.getColumnIndexOrThrow(DbHelper.COLUMN_IS_FOUND));


            nameTextView.setText(name);

            phoneTextView.setText(phone);

            descriptionTextView.setText(description);

            locationTextView.setText(location);

            dateTextView.setText(date);

            if (isLost == 1) {
                statusTextView.setText("Status: Lost");
            } else if (isFound == 1) {
                statusTextView.setText("Status: Found");
            }
        }

        cursor.close();
        Button removeButton = findViewById(R.id.button_remove_item);
        removeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                int itemId = getIntent().getIntExtra("itemId", -1);
                String selection = DbHelper.COLUMN_ID + " = ?";
                String[] selectionArgs = { Integer.toString(itemId) };
                db.delete(DbHelper.TABLE_NAME, selection, selectionArgs);
                dbHelper.close();
                Toast.makeText(ItemDetails.this, "The item you chose has been removed from the database", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(ItemDetails.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
            //this code removes the item from the db, sends a toast too
    }

    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }
}
